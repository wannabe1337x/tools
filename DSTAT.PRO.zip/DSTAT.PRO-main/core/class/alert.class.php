<?php

/*----------------------------------
	============================
	Website: stresserit.pro
	Author: Hazze
	Website url: https://stresserit.pro/
	============================
-----------------------------------*/

class Alert {

	public function SaveAlert($msg_txt, $msg_mode) {
		if ($msg_mode == 'success') {
			$_SESSION['msg_success'] = $msg_txt;
		} else if ($msg_mode == 'error') {
			$_SESSION['msg_error'] = $msg_txt;
		} else if ($msg_mode == 'info') {
			$_SESSION['msg_info'] = $msg_txt;
		} else if ($msg_mode == 'warning') {
			$_SESSION['msg_warning'] = $msg_txt;
		} else {
			echo "Error.";
		}
		
	}

	
	
	public function LoginAlert($msg_txt, $msg_mode) {
		if ($msg_mode == 'success') {
			$_SESSION['msg_success_log'] = $msg_txt;
		} else if ($msg_mode == 'error') {
			$_SESSION['msg_error_log'] = $msg_txt;
		} else if ($msg_mode == 'info') {
			$_SESSION['msg_info_log'] = $msg_txt;
		} else if ($msg_mode == 'warning') {
			$_SESSION['msg_warning_log'] = $msg_txt;
		} else {
			echo "Error.";
		}
	}
	

	public function SaveAlertAdmin($msg_txt, $msg_mode) {
		if ($msg_mode == 'success') {
			$_SESSION['msg_success'] = $msg_txt;
		} else if ($msg_mode == 'error') {
			$_SESSION['msg_error'] = $msg_txt;
		} else if ($msg_mode == 'info') {
			$_SESSION['msg_info'] = $msg_txt;
		} else if ($msg_mode == 'warning') {
			$_SESSION['msg_warning'] = $msg_txt;
		} else {
			echo "Error.";
		}
	}
	public function PrintAlert() {
		//empty.
		$eAlert = '';

		if (isset($_SESSION['msg_success'])) {
			$eMSG = $_SESSION['msg_success'];
			$eAlert = '<script>Notify("'.$eMSG.'", "success")</script>';
		} else if (isset($_SESSION['msg_error'])) {
			$eMSG = $_SESSION['msg_error'];
			$eAlert = '<script>Notify("'.$eMSG.'", "error")</script>';
		} else if (isset($_SESSION['msg_info'])) {
			$eMSG = $_SESSION['msg_info'];
			$eAlert = '<script>Notify("'.$eMSG.'", "info")</script>';
		} else if (isset($_SESSION['msg_warning'])) {
			$eMSG = $_SESSION['msg_warning'];
			$eAlert = '<script>Notify("'.$eMSG.'", "warning")</script>';
		} else {
			$eMSG = "";
		}

		return $eAlert;
	}


	public function PrintAlertAdmin() {
		//empty.
		$eAlert = '';

		if (isset($_SESSION['msg_success'])) {
			$eMSG = $_SESSION['msg_success'];

			$eAlert = '<script type="text/javascript">
			setTimeout(function(){ 
				Notify("'.$eMSG.'", "success");
			});
		</script>';
		} else if (isset($_SESSION['msg_error'])) {
			$eMSG = $_SESSION['msg_error'];

			$eAlert = '<script type="text/javascript">
			setTimeout(function(){ 
				Notify("'.$eMSG.'", "error");
			});
		</script>';
		} else if (isset($_SESSION['msg_info'])) {
			$eMSG = $_SESSION['msg_info'];

			$eAlert = '<script type="text/javascript">
			setTimeout(function(){ 
				Notify("'.$eMSG.'", "info");
			});
		</script>';
		} else if (isset($_SESSION['msg_warning'])) {
			$eMSG = $_SESSION['msg_warning'];

			$eAlert = '<script type="text/javascript">
				setTimeout(function(){ 
					Notify("'.$eMSG.'", "warning");
				});
			</script>';
		} else if (isset($_SESSION['msg_success_log'])) {
			$eMSG = $_SESSION['msg_success_log'];

			$eAlert = '<script type="text/javascript">
			setTimeout(function(){ 
				$.toast("'.$eMSG.'", "success");
			});
		</script>';
		} else if (isset($_SESSION['msg_error_log'])) {
			$eMSG = $_SESSION['msg_error_log'];

			$eAlert = '<script type="text/javascript">
			setTimeout(function(){ 
				$.toast("'.$eMSG.'", "error");
			});
		</script>';
		} else if (isset($_SESSION['msg_info_log'])) {
			$eMSG = $_SESSION['msg_info_log'];

			$eAlert = '<script type="text/javascript">
			setTimeout(function(){ 
				$.toast("'.$eMSG.'", "info");
			});
		</script>';
		} else if (isset($_SESSION['msg_warning_log'])) {
			$eMSG = $_SESSION['msg_warning_log'];

			$eAlert = '<script type="text/javascript">
				setTimeout(function(){ 
					$.toast("'.$eMSG.'", "warning");
				});
			</script>';
		} else {
			$eMSG = "";
		}

		return $eAlert;
	}

	public function RemoveAlert() {
		if (isset($_SESSION['msg_success'])) {
			unset($_SESSION['msg_success']);
		} else if (isset($_SESSION['msg_error'])) {
			unset($_SESSION['msg_error']);
		} else if (isset($_SESSION['msg_info'])) {
			unset($_SESSION['msg_info']);
		} else if (isset($_SESSION['msg_warning'])) {
			unset($_SESSION['msg_warning']);
		} else {
			
		}
	}


	
	
}