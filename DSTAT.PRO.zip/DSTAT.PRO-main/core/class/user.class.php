<?php

/*----------------------------------
	============================
	Website: stresserit.pro
	Author: Hazze
	Website url: https://stresserit.pro/
	============================
-----------------------------------*/

class User {

	/* Login */
	public function LogIn($Username, $Password) {
		global $DataBase;

		$DataBase->Query("SELECT id, username, password FROM `users` WHERE `username` = :Username ORDER by `id` DESC LIMIT 1");
		$DataBase->Bind(':Username', $Username);
		$DataBase->Execute();
		$UserData = $DataBase->Single();

		// if ($UserData['status'] != 1) {
		// 	$rMsg = ['error', 'Your account has been deactivated or deleted!'];
		// 	echo json_encode($rMsg);
		// 	die();
		// }

		$UserCount 	= $DataBase->RowCount();

		$Check = md5($Password) == $UserData['password'];

		if($UserCount != 0 && $Check) {
			$_SESSION['UserLogin']['ID'] 	= $UserData['id']; // User ID

			// Get Current date, time
			$current_time = time();
			// set cookie exp
			$cookie_expiration_time = $current_time + (86400 * 30);  // for 1 day
			setcookie('member_login', '1', $cookie_expiration_time);
			setcookie('_cflogin', $UserData['id'].'_'.$current_time, $cookie_expiration_time, '/', null, null, TRUE);
			return true;
		} else {
			return false;
		}
	}

	
	public function UserDataAll() {
		global $DataBase;

		$DataBase->Query("SELECT * FROM `users`");
		$DataBase->Execute();

		$Return = array(
			'Count' => $DataBase->RowCount(),
			'Response' => $DataBase->ResultSet()
		);

		return $Return;
	}
	
	/* Is User Logged In */
	public function IsLoged() {
		global $User;

		if(isset($_SESSION['UserLogin']['ID']) && !empty($User->UserDataID($_SESSION['UserLogin']['ID'], 1)['id'])) {
			$return = true;
		} else {
			$return = false;
		}
		return $return;
	}



	/* Get User Information by SESSION */
	public function UserData() {
		global $DataBase;

		if(isset($_SESSION['UserLogin'])) {
			$DataBase->Query("SELECT * FROM `users` WHERE `id` = :userID");
			$DataBase->Bind(':userID', $_SESSION['UserLogin']['ID']);
			$DataBase->Execute();

			return $DataBase->Single();
		} else {
			return false;
		}
	}

	/* Get User Information by ID */
	// public function UserDataID($userID) {
	// 	global $DataBase;

	// 	$DataBase->Query("SELECT * FROM `users` WHERE `id` = :userID");
	// 	$DataBase->Bind(':userID', $userID);
	// 	$DataBase->Execute();

	// 	return $DataBase->Single();
	// }

	public function UserDataID($id, $num) {
		global $DataBase;

		$DataBase->Query("SELECT * FROM `users` WHERE `id` = :ID");
		$DataBase->Bind(':ID', $id);
		$DataBase->Execute();

		if($num == 0) {
			$Return = array(
				'Count' => $DataBase->RowCount(),
				'Response' => $DataBase->ResultSet()
			);
	
			return $Return;
		} else {
			return $DataBase->Single();
		}
	}



	/* Get User Information by Username */
	public function UserDataIDusername($Username) {
		global $DataBase;

		$DataBase->Query("SELECT * FROM `users` WHERE `username` = :Username");
		$DataBase->Bind(':Username', $Username);
		$DataBase->Execute();

		return $DataBase->Single();
	}

	public function ChangePassword($Password, $userID) {
		global $DataBase;
		global $Logs;
		global $User;

		$DataBase->Query("UPDATE `users` SET `password`=:Pass WHERE `id`=:uID");
		$DataBase->Bind(':Pass', $Password);
		$DataBase->Bind(':uID', $userID);

		$DataBase->Execute();

		// Log
		$Logs->CreateLog($userID, $User->UserDataID($userID, 0)["username"], 'User has changed password!');
	}


	/* Get User by ID */
	public function CountUserByID($userID) {
		global $DataBase;

		$DataBase->Query("SELECT * FROM `users` WHERE `id` = :ID");
		$DataBase->Bind(':ID', $userID);
		$DataBase->Execute();

		$nArr = Array(
			'Count' 	=> $DataBase->RowCount()
		);
		return $nArr;
	}

	/* Get All Users */
	public function userList() {
		global $DataBase;

		$DataBase->Query("SELECT * FROM `users` ORDER by `id` ASC");
		$DataBase->Execute();

		$Return = Array(
			'Response' 	=> $DataBase->ResultSet(),
			'Count' 	=> $DataBase->RowCount()
		);
		return $Return;
	}

	/* close acc */
	public function userCloseAccount($userID) {
		global $DataBase;

		$DataBase->Query("DELETE FROM `users` WHERE id = :userID");
		$DataBase->Bind(':userID', $userID);

		if(!$DataBase->Execute()) {
			return false;
		} else {
			return true;
		}
	}


	/* register */
	public function Register($Username, $Password, $Mail) {
		global $DataBase;
		global $Logs;
		

        $DataBase->Query("INSERT INTO `users` (`id`, `username`, `email`, `password`, `registerdate`, `telegram`, `fullname`, `website`, `rank`) VALUES (NULL, :Username, :Email, :Password, :regDate, :Telegram, :Name, :Website, :Rank);");
		$DataBase->Bind(':Username', $Username);
		$DataBase->Bind(':Email', $Mail);
		$DataBase->Bind(':Password', md5($Password));
		$DataBase->Bind(':regDate', time());     
        $DataBase->Bind(':Telegram', "");     
		$DataBase->Bind(':Name', "");     
		$DataBase->Bind(':Website', "");     
		$DataBase->Bind(':Rank', 0);     
    
		if(!$DataBase->Execute()) {
			return false;
		} else {
			return true;
		}



	}


	public function UserIP() {
		// $ipaddress = '';
		// if (isset($_SERVER['HTTP_CLIENT_IP']))
		// 	$ipaddress = $_SERVER['HTTP_CLIENT_IP'];
		// else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
		// 	$ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
		// else if(isset($_SERVER['HTTP_X_FORWARDED']))
		// 	$ipaddress = $_SERVER['HTTP_X_FORWARDED'];
		// else if(isset($_SERVER['HTTP_X_CLUSTER_CLIENT_IP']))
		// 	$ipaddress = $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'];
		// else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
		// 	$ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
		// else if(isset($_SERVER['HTTP_FORWARDED']))
		// 	$ipaddress = $_SERVER['HTTP_FORWARDED'];
		// else if(isset($_SERVER['REMOTE_ADDR']))
		// 	$ipaddress = $_SERVER['REMOTE_ADDR'];
		// else
		// 	$ipaddress = 'UNKNOWN';
		// return $ipaddress;

		if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
			$_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
			$_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
 		}
		$client  = @$_SERVER['HTTP_CLIENT_IP'];
		$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
		$remote  = $_SERVER['REMOTE_ADDR'];

		if(filter_var($client, FILTER_VALIDATE_IP)) { $ip = $client; }
		elseif(filter_var($forward, FILTER_VALIDATE_IP)) { $ip = $forward; }
		else { $ip = $remote; }

		return $ip;
   		}

    public function Geo($shit='country') {
        global $User;
        
	    if (!$_SERVER['HTTP_HOST'] == 'localhost') {
            $Ip = $User->UserIP();
        } else {
            $Ip = '1.1.1.1';
        }

		$json     = file_get_contents("http://ipinfo.io/$Ip/geo");
        $json     = json_decode($json, true);
        $dzison = $json[$shit];

		return $dzison;
    }

	public function ChangeUser($userID, $Fullname, $Telegram, $Website, $Pw) {
		global $DataBase;
		global $User;
		global $Secure;

		if($Pw != '0') {
			$DataBase->Query("UPDATE `users` SET `fullname`=:Fullname,`telegram`=:Telegram,`website`=:Website,`password`=:Pw WHERE `id`=:uID");
			$DataBase->Bind(':uID', $userID);
			$DataBase->Bind(':Fullname', $Fullname);
			$DataBase->Bind(':Telegram', $Telegram);
			$DataBase->Bind(':Website', $Website);
			$DataBase->Bind(':Pw', md5($Pw));

			$ez = $DataBase->Execute();

			if($ez == false) {
				$rMsg = ['error', 'Error'];
				echo json_encode($rMsg);
				die();
			} else {
				$rMsg = ['success', 'Successfully executed!'];
				echo json_encode($rMsg);
				die();
			}
		} else {
			$DataBase->Query("UPDATE `users` SET `fullname`=:Fullname,`telegram`=:Telegram,`website`=:Website WHERE `id`=:uID");
			$DataBase->Bind(':uID', $userID);
			$DataBase->Bind(':Fullname', $Fullname);
			$DataBase->Bind(':Telegram', $Telegram);
			$DataBase->Bind(':Website', $Website);

			$ez = $DataBase->Execute();

			if($ez == false) {
				$rMsg = ['error', 'Error'];
				echo json_encode($rMsg);
				die();
			} else {
				$rMsg = ['success', 'Successfully executed!'];
				echo json_encode($rMsg);
				die();
			}
		}
	}

	public function ModifyUser($userID, $Username, $Fullname, $Rank, $Telegram, $Email, $Website, $Pw) {
		global $DataBase;
		global $User;
		global $Secure;

		if($Pw != '0') {
			$DataBase->Query("UPDATE `users` SET `username`=:Username, `email`=:Email, `password`=:Password, `telegram`=:Telegram, `fullname`=:Fullname, `website`=:Website, `rank`=:Rank WHERE `id`=:uID");
			$DataBase->Bind(':uID', $userID);
			$DataBase->Bind(':Username', $Username);
			$DataBase->Bind(':Email', $Email);
			$DataBase->Bind(':Password', md5($Pw));
			$DataBase->Bind(':Telegram', $Telegram);
			$DataBase->Bind(':Fullname', $Fullname);
			$DataBase->Bind(':Website', $Website);
			$DataBase->Bind(':Rank', $Rank);

			$ez = $DataBase->Execute();

			if($ez == false) {
				$rMsg = ['error', 'Something went wrong.'];
				echo json_encode($rMsg);
				die();
			} else {
				$rMsg = ['success', 'Successfully executed.'];
				echo json_encode($rMsg);
				die();
			}
		} else {
			$DataBase->Query("UPDATE `users` SET `username`=:Username, `email`=:Email, `telegram`=:Telegram, `fullname`=:Fullname, `website`=:Website, `rank`=:Rank WHERE `id`=:uID");
			$DataBase->Bind(':uID', $userID);
			$DataBase->Bind(':Username', $Username);
			$DataBase->Bind(':Email', $Email);
			$DataBase->Bind(':Telegram', $Telegram);
			$DataBase->Bind(':Fullname', $Fullname);
			$DataBase->Bind(':Website', $Website);
			$DataBase->Bind(':Rank', $Rank);

			$ez = $DataBase->Execute();

			if($ez == false) {
				$rMsg = ['error', 'Error'];
				echo json_encode($rMsg);
				die();
			} else {
				$rMsg = ['success', 'Successfully executed!'];
				echo json_encode($rMsg);
				die();
			}
		}
	}
}