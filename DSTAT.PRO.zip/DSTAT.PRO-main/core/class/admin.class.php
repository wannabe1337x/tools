<?php

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *   file                 :  user.class.php
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *   author               :  Muhamed Skoko - mskoko.me@gmail.com
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

class Admin {

	public function LogIn($Username, $Password) {
		global $DataBase;
		global $User;
		global $Alert;
		global $Secure;

		$DataBase->Query("SELECT * FROM `admins` WHERE `username` = :Username");
		$DataBase->Bind(':Username', $Username);
		$DataBase->Execute();

		$UserData 	= $DataBase->Single();

		$UserCount 	= $DataBase->RowCount();

		$Provera = md5($Password) == $UserData['password'];

		if($UserCount == true && $Provera) {
			$_SESSION['AdminLogin']['ID'] = $UserData['id'];

			if(isset($_COOKIE['accept_cookie']) && $_COOKIE['accept_cookie'] == '1') {
				// Get Current date, time
				$current_time = time();

				// Set Cookie expiration for 1 month
				$cookie_expiration_time = $current_time + (30 * 24 * 60 * 60);  // for 1 month

				setcookie('member_login', '1', $cookie_expiration_time);
				//Set Secure Cookies -> HttpOnly
				setcookie('l0g1n', $UserData['Token'].'_'.$UserData['id'], $cookie_expiration_time, '/', null, null, TRUE);
			}
			$Alert->SaveAlert('Welcome back!', 'success');
			header('Location: index.php?ok');
			die();
		} else {
			$Alert->LoginAlert('You have entered incorrect information. Please try again!', 'error');
			header('Location: login.php?ok');
			die();
		}
	}

	public function AdminDataByUsername($Username) {
		global $DataBase;

		$DataBase->Query("SELECT * FROM `admins` WHERE `username` = :Username");
		$DataBase->Bind(':Username', $Username);
		$DataBase->Execute();

		$Return = array(
			'Count' => $DataBase->RowCount()
		);

		return $Return;
	}

	public function AdminDataAll() {
		global $DataBase;

		$DataBase->Query("SELECT * FROM `admins`");
		$DataBase->Execute();

		$Return = array(
			'Count' => $DataBase->RowCount(),
			'Response' => $DataBase->ResultSet()
		);

		return $Return;
	}



	/* Is Admin Logged In */
	public function IsLoged() {
		global $Admin;

		if(isset($_SESSION['AdminLogin'])) {
			$return = true;
		} else {
			if (isset($_COOKIE['bl_l0g1n'])) {
				$GetUid = explode('_', $_COOKIE['bl_l0g1n']);
				if (!empty($GetUid[1])) {
					if (!empty($Admin->UserDataID($GetUid[1])['id'])) {
						if ($Admin->UserDataID($GetUid[1])['Token'] == $GetUid[0]) {
							$return = $Admin->ProduziLogin($GetUid[1]);
						} else {
							$return = false;
						}
					}
				} else {
					$return = false;
				}
			} else {
				$return = false;
			}

			$return = false;
		}

		return $return;
	}

	public function AdminDataIDSignle($uID) {
		global $DataBase;

		$DataBase->Query("SELECT * FROM `admins` WHERE `id` = :uID");
		$DataBase->Bind(':uID', $uID);
		$DataBase->Execute();

		return $DataBase->Single();
	}

	/* new session (produzi login) */
	public function ProduziLogin($uID) {
		global $Admin;

		if (!empty($uID) && is_numeric($uID)) {
			if (!empty($Admin->AdminDataID($uID)['id'])) {
				$_SESSION['AdminLogin']['ID'] = $uID;
				$return = true;
			} else {
				$return = false;
			}
		}
		return $return;
	}

	public function getUsername($adminID) {
		global $Admin, $Secure;

		return $Secure->SecureTxt($Admin->AdminDataID($adminID)['username']);
	}

	public function ChangeUser($userID, $Username, $Plan, $Expire, $Money, $Status, $Pw) {
		global $DataBase;
		global $User;
		global $Secure;
		global $lang;

		if(!$Pw == '0') {
			$DataBase->Query("UPDATE `users` SET `username`=:Username,`plan`=:Plan,`expire`=:Expire,`money`=:Money,`status`=:Status,`password`=:Pw WHERE `id`=:uID");
			$DataBase->Bind(':Username', $Username);
			$DataBase->Bind(':Plan', $Plan);
			$DataBase->Bind(':Expire', $Expire);
			$DataBase->Bind(':Money', $Money);
			$DataBase->Bind(':Status', $Status);
			$DataBase->Bind(':Pw', md5($Pw));
			$DataBase->Bind(':uID', $userID);

			$ez = $DataBase->Execute();

			if($ez == false) {
				$rMsg = ['error', 'Error'];
				echo json_encode($rMsg);
				die();
			} else {
				$rMsg = ['success', 'Successfully executed!'];
				echo json_encode($rMsg);
				die();
			}
		} else {
			$DataBase->Query("UPDATE `users` SET `username`=:Username,`plan`=:Plan,`expire`=:Expire,`money`=:Money,`status`=:Status WHERE `id`=:uID");
			$DataBase->Bind(':Username', $Username);
			$DataBase->Bind(':Plan', $Plan);
			$DataBase->Bind(':Expire', $Expire);
			$DataBase->Bind(':Money', $Money);
			$DataBase->Bind(':Status', $Status);
			$DataBase->Bind(':uID', $userID);

			$ez = $DataBase->Execute();

			if($ez == false) {
				$rMsg = ['error', 'Error'];
				echo json_encode($rMsg);
				die();
			} else {
				$rMsg = ['success', 'Successfully executed!'];
				echo json_encode($rMsg);
				die();
			}
		}
	}

	public function banUser($userID) {
		global $DataBase;

		$DataBase->Query("UPDATE `users` SET `banned`='1' WHERE `id`=:uID");
		$DataBase->Bind(':uID', $userID);
		$ez = $DataBase->Execute();

		if($ez == false) {
			return false;
		} else {
			return true;
		}
	}

	public function unbanUser($userID) {
		global $DataBase;

		$DataBase->Query("UPDATE `users` SET `banned`='0' WHERE `id`=:uID");
		$DataBase->Bind(':uID', $userID);
		$ez = $DataBase->Execute();

		if($ez == false) {
			return false;
		} else {
			return true;
		}
	}

	public function removeUser($userID) {
		global $DataBase;

		$DataBase->Query("DELETE FROM `users` WHERE `id`=:uID");
		$DataBase->Bind(':uID', $userID);
		$ez = $DataBase->Execute();

		if($ez == false) {
			return false;
		} else {
			return true;
		}
	}

	/* Get Admin Information by SESSION */
	public function AdminData() {
		global $DataBase;

		if(isset($_SESSION['AdminLogin'])) {
			$DataBase->Query("SELECT * FROM `admins` WHERE `id` = :userID");
			$DataBase->Bind(':userID', $_SESSION['AdminLogin']['ID']);
			$DataBase->Execute();

			return $DataBase->Single();
		} else {
			return false;
		}
	}

	/* Get Admin Information by ID */
	// public function AdminDataID($adminID) {
	// 	global $DataBase;

	// 	$DataBase->Query("SELECT * FROM `admins` WHERE `id` = :adminID;");
	// 	$DataBase->Bind(':adminID', $adminID);
	// 	$DataBase->Execute();

	// 	return $DataBase->Single();
	// }

	public function AdminDataID($id, $num) {
		global $DataBase;

		$DataBase->Query("SELECT * FROM `admins` WHERE `id` = :ID");
		$DataBase->Bind(':ID', $id);
		$DataBase->Execute();

		if($num == 0) {
			$Return = array(
				'Count' => $DataBase->RowCount(),
				'Response' => $DataBase->ResultSet()
			);

			return $Return;
		} else {
			return $DataBase->Single();
		}
	}


	/* Get Admin Full name by adminID */
	public function getFullName($adminID) {
		global $Admin, $Secure;

		return $Secure->SecureTxt($Admin->AdminDataID($adminID)['Name'].' '.$Admin->AdminDataID($adminID)['Lastname']);
	}

	/* Admins list */
	public function adminList() {
		global $DataBase;

		$DataBase->Query("SELECT * FROM `admins`");
		$DataBase->Execute();

		$nArr = Array(
			'Response' 	=> $DataBase->ResultSet(),
			'Count' 	=> $DataBase->RowCount()
		);
		return $nArr;
	}

	/* Admin Rank */
	public function adminRank($Rank) {
		if (isset($Rank) && empty($Rank)) {
			$nArr = ['white', 'Rank?'];
		} else if($Rank == '1') {
			$nArr = ['#00ffff', 'Support', '1'];
		} else if($Rank == '2') {
			$nArr = ['#0091ea', 'Glavni Support', '2'];
		} else if($Rank == '3') {
			$nArr = ['red', 'Administrator', '3'];
		} else if($Rank == '4') {
			$nArr = ['#8affa9', 'Developer', '4'];
		} else if($Rank == '5') {
			$nArr = ['#00ff43', 'Owner', '5'];
		}
		return $nArr;
	}

	/* Get Admin by ID */
	public function CountAdminByID($userID) {
		global $DataBase;

		$DataBase->Query("SELECT * FROM `admins` WHERE `id` = :ID");
		$DataBase->Bind(':ID', $userID);
		$DataBase->Execute();

		$nArr = Array(
			'Count' 	=> $DataBase->RowCount()
		);
		return $nArr;
	}

	/* Add new Worker */
	public function addNewAdmin($Username, $Password, $Email, $Name, $LastName, $Rank, $admPerm, $suppZa, $AdminID) {
		global $DataBase;

		$DataBase->Query("INSERT INTO `admins` (`id`, `Username`, `Password`, `Email`, `Name`, `Lastname`, `Image`, `Token`, `Rank`, `Status`, `AdminPerm`, `AdminSupp`, `createdBy`, `lastactivity`) VALUES (NULL, :Username, :Password, :Email, :Name, :Lastname, :Image, :Token, :Rank, :Status, :AdminPerm, :AdminSupp, :createdBy, :lastactivity);");
		$DataBase->Bind(':Username', $Username);
		$DataBase->Bind(':Password', $Password);
		$DataBase->Bind(':Email', $Email);
		$DataBase->Bind(':Name', $Name);
		$DataBase->Bind(':Lastname', $LastName);
		$DataBase->Bind(':Image', 'assets/img/i/logo/logo.png');
		$DataBase->Bind(':Token', '1312');
		$DataBase->Bind(':Rank', $Rank);
		$DataBase->Bind(':Status', '1');
		$DataBase->Bind(':AdminPerm', $admPerm);
		$DataBase->Bind(':AdminSupp', $suppZa);
		$DataBase->Bind(':createdBy', $AdminID);
		$DataBase->Bind(':lastactivity', time());
		
		return $DataBase->Execute();
	}

	/* Admin Perm is valid */
	public function AdminPermValid($adminID, $suppZa) {
		global $Admin;
		// fixed
		$return = false;
		// Get admin permision
		$admPerm = $Admin->AdminDataID($adminID)['AdminPerm'];
		if(empty($admPerm)) {
			$return = false;
		} else {
			$admPerm = @unserialize($admPerm);
			if(isset($admPerm) && empty($admPerm[0])) {
				$return = false;
			} else {
				if (in_array($suppZa, $admPerm)) {
					$return = true;
				} else {
					$return = false;
				}
			}
		}
		return $return;
	}

	/* Support Perm is valid */
	public function suppPermValid($adminID, $gameID) {
		global $Admin;
		// fixed
		$return = false;
		// Get admin permision
		$suppPerm = $Admin->AdminDataID($adminID)['AdminSupp'];
		if(empty($suppPerm)) {
			$return = false;
		} else {
			$suppPerm = @unserialize($suppPerm);
			if(isset($suppPerm) && empty($suppPerm[0])) {
				$return = false;
			} else {
				if (in_array($gameID, $suppPerm)) {
					$return = true;
				} else {
					$return = false;
				}
			}
		}
		return $return;
	}

}