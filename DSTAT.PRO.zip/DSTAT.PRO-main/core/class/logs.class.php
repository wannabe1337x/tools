<?php

/*----------------------------------
	============================
	Website: stresserit.pro
	Author: Hazze
	Website url: https://stresserit.pro/
	============================
-----------------------------------*/

class Logs {

	public function LogsDataAll() {
		global $DataBase;

		$DataBase->Query("SELECT * FROM `logs`");
		$DataBase->Execute();

		$Return = array(
			'Count' => $DataBase->RowCount(),
			'Response' => $DataBase->ResultSet()
		);

		return $Return;
	}


	public function ToolLogsDataAll() {
		global $DataBase;

		$DataBase->Query("SELECT * FROM `tools_logs`");
		$DataBase->Execute();

		$Return = array(
			'Count' => $DataBase->RowCount(),
			'Response' => $DataBase->ResultSet()
		);

		return $Return;
	}

	public function UserLogsDataAll() {
		global $DataBase;

		$DataBase->Query("SELECT * FROM `user_logs`");
		$DataBase->Execute();

		$Return = array(
			'Count' => $DataBase->RowCount(),
			'Response' => $DataBase->ResultSet()
		);

		return $Return;
	}

	public function LogsDataID($id, $num) {
		global $DataBase;

		$DataBase->Query("SELECT * FROM `logs` WHERE `userID` = :ID");
		$DataBase->Bind(':ID', $id);
		$DataBase->Execute();

		if($num == 0) {
			$Return = array(
				'Count' => $DataBase->RowCount(),
				'Response' => $DataBase->ResultSet()
			);
	
			return $Return;
		} else {
			return $DataBase->Single();
		}
	}

    public function CreateLog($userID, $username, $Text) {
		global $DataBase;
		global $User;

		$DataBase->Query("INSERT INTO `logs` (`id`, `userID`, `username`, `action`, `timestamp`, `ip`) VALUES (NULL, :userID, :username, :action, :timestamp, :ip);");
		$DataBase->Bind(':userID', $userID);
		$DataBase->Bind(':username', $username);
		$DataBase->Bind(':action', $Text);
		$DataBase->Bind(':timestamp', time());
		$DataBase->Bind(':ip', $User->UserIP());

		return $DataBase->Execute();
	}


	public function CreateToolsLog($userID, $type, $value) {
		global $DataBase;
		global $User;

		$DataBase->Query("INSERT INTO `tools_logs` (`id`, `userID`, `type`, `value`, `date`, `ip`) VALUES (NULL, :userID, :Type, :value, :timestamp, :ip);");
		$DataBase->Bind(':userID', $userID);
		$DataBase->Bind(':Type', $type);
		$DataBase->Bind(':value', $value);
		$DataBase->Bind(':timestamp', time());
		$DataBase->Bind(':ip', $User->UserIP());

		return $DataBase->Execute();
	}

	public function CreateUserLog($userID, $Username, $Action) {
		global $DataBase;
		global $User;

		$DataBase->Query("INSERT INTO `user_logs` (`id`, `userID`, `username`, `action`, `date`, `ip`) VALUES (NULL, :userID, :Username, :Action, :timestamp, :ip);");
		$DataBase->Bind(':userID', $userID);
		$DataBase->Bind(':Username', $Username);
		$DataBase->Bind(':Action', $Action);
		$DataBase->Bind(':timestamp', time());
		$DataBase->Bind(':ip', $User->UserIP());

		return $DataBase->Execute();
	}

	public function deleteUserLog($logID) {
		global $DataBase;
		
		$DataBase->Query("DELETE FROM `logs` WHERE id = :logID");
		$DataBase->Bind(':logID', $logID);

		if(!$DataBase->Execute()) {
			return false;
		} else {
			return true;
		}
	}

	public function deleteUserLogs() {
		global $DataBase;
		
		$DataBase->Query("DELETE FROM logs;");

		if(!$DataBase->Execute()) {
			return false;
		} else {
			return true;
		}
	}

}

?>